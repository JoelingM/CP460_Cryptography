#--------------------------
# CP460 (Fall 2019)
# Final Exam
# Joseph Myc
# 160 740 900
#--------------------------

import math
import string
import mod
import utilities

configFile = 'SDES_config.txt'
sbox1File = 'sbox1.txt'
sbox2File = 'sbox2.txt'
primeFile = 'primes.txt'

#-----------------------
# Q1: Coding Scheme
#-----------------------
#-----------------------------------------------------------
# Parameters:   c (str): a character
#               codeType (str)
# Return:       b (str): corresponding binary number
# Description:  Generic function for encoding
#               Current implementation supports only ASCII and B6 encoding
# Error:        If c is not a single character:
#                   print('Error(encode): invalid input'), return ''
#               If unsupported encoding type:
#                   print('Error(encode): Unsupported Coding Type'), return '' 
#-----------------------------------------------------------
def encode(c,codeType):
    supported = utilities.get_B6Code()
    if (not isinstance(c, str) or len(c) != 1 or c not in supported):
        print('Error(encode): invalid input', end = "")
        return ''   
    if (codeType != "ASCII" and codeType != "B6"):
        print('Error(encode): Unsupported Coding Type', end = "")
        return '' 
        
    if (codeType == "ASCII"):
        b = "{0:b}".format(ord(c)).zfill(8)
    elif (codeType == "B6"):
        b = "{0:b}".format(supported.index(c)).zfill(6)
    else:
        b = "Unknown Error"
        
    return b

#-----------------------------------------------------------
# Parameters:   b (str): a binary number
#               codeType (str)
# Return:       c (str): corresponding character
# Description:  Generic function for decoding
#               Current implementation supports only ASCII and B6 encoding
# Error:        If c is not a binary number:
#                   print('Error(decode): invalid input',end =''), return ''
#               If unsupported encoding type:
#                   print('Error(decode): Unsupported Coding Type',end =''), return '' 
#-----------------------------------------------------------
def decode(b,codeType):
    if not isinstance(b, str):
        print('Error(decode): invalid input',end ='')
        return ''
    p = set(b) 
    s = {'0', '1'} 
    code = utilities.get_B6Code()
    if not (s == p or p == {'0'} or p == {'1'}):
        print('Error(decode): invalid input',end ='')
        return ''
    if (codeType != "ASCII" and codeType != "B6"):
        print('Error(encode): Unsupported Coding Type', end = '')
        return '' 
    
    if (codeType == "ASCII"):
        c = chr(int(b, 2))
    elif (codeType == "B6"):
        c = code[int(b, 2)]
    else:
        c = "Unknown Error"
    return c

#-----------------------------------------------------------
# Parameters:   c (str): a character
# Return:       b (str): 6-digit binary code
# Description:  Encodes any given symbol in the B6 Encoding scheme
#               If given symbol is one of the 64 symbols, the function returns
#               the binary representation, which is the equivalent binary number
#               of the decimal value representing the position of the symbol in the B6Code
#               If the given symbol is not part of the B6Code --> return empty string (no error msg)
# Error:        If given input is not a single character -->
#                   print('Error(encode_B6): invalid input',end =''), return ''
#-----------------------------------------------------------
def encode_B6(c):
    supported = utilities.get_B6Code()
    if (not isinstance(c, str) or len(c) != 1):
        print('Error(encode_B6): invalid input', end = "")
        return ''   
    if (c not in supported):
        return ''

    b = "{0:b}".format(supported.index(c)).zfill(6)
    return b

#-----------------------------------------------------------
# Parameters:   b (str): binary number
# Return:       c (str): a character
# Description:  Decodes any given binary code in the B6 Coding scheme
#               Converts the binary number into integer, then get the
#               B6 code at that position
# Error:        If given input is not a valid 6-bit binary number -->
#                   print('Error(decode_B6): invalid input',end =''), return ''
#-----------------------------------------------------------
def decode_B6(b):
    if not isinstance(b, str) or len(b) != 6:
        print('Error(decode_B6): invalid input',end ='')
        return ''
    p = set(b) 
    s = {'0', '1'} 
    code = utilities.get_B6Code()
    if not (s == p or p == {'0'} or p == {'1'} or len(b) != 6):
        print('Error(decode_B6): invalid input',end ='')
        return ''

    c = code[int(b, 2)]
    return c

#-----------------------
# Q2: SDES Configuration
#-----------------------
#-----------------------------------------------------------
# Parameters:   None
# Return:       paramList (list)
# Description:  Returns a list of parameter names which are used in
#               Configuration of SDES
# Error:        None
#-----------------------------------------------------------
def get_SDES_parameters():
    return ['encoding_type','block_size','key_size','rounds','p','q']

#-----------------------------------------------------------
# Parameters:   None
# Return:       configList (2D List)
# Description:  Returns the current configuraiton of SDES
#               configuration list is formatted as the following:
#               [[parameter1,value],[parameter2,value2],...]
#               The configurations are read from the configuration file
#               If configuration file is empty --> return []
# Error:        None
#-----------------------------------------------------------
def get_SDES_config():
    configList = []
    with open(configFile, 'r') as file:
        for line in file:
            tempArray = line.split(',')
            tempArray[1] = tempArray[1].strip()
            configList.append(tempArray)
    
    return configList

#-----------------------------------------------------------
# Parameters:   parameter (str)
# Return:       value (str)
# Description:  Returns the value of the parameter based on the current
# Error:        If the parameter is undefined in get_SDES_parameters() -->
#                   print('Error(get_SDES_value): invalid parameter',end =''), return ''
#-----------------------------------------------------------
def get_SDES_value(parameter):
    value = ''
    if parameter not in get_SDES_parameters():
        print('Error(get_SDES_value): invalid parameter',end ='')
        return ''

    with open(configFile, 'r') as file:
        for line in file:
            words = line.split(',')
            if words[0] == parameter:
                value = words[1].strip()

    return value

#-----------------------------------------------------------
# Parameters:   parameter (str)
#               value (str)
# Return:       True/False
# Description:  Sets an SDES parameter to the given value and stores
#               the output in the configuration file
#               if the configuration file contains previous value for the parameter
#               the function overrides it with the new value
#               otherwise, the new value is appended to the configuration file
#               Function returns True if set value is successful and False otherwise
# Error:        If the parameter is undefined in get_SDES_parameters() -->
#                   print('Error(cofig_SDES): invalid parameter',end =''), return False
#               If given value is not a string or is an empty string:
#                   print('Error(config_SDES): invalid value',end =''), return 'False
#-----------------------------------------------------------
def config_SDES(parameter,value):
    if parameter not in get_SDES_parameters():
        print('Error(cofig_SDES): invalid parameter',end ='')
        return False

    if not isinstance(value, str) or len(value) == 0:
        print('Error(config_SDES): invalid value',end ='')
        return False

    configArray = get_SDES_config()   

    contains = False
    for item in configArray:
        if item[0] == parameter:
            contains = True

    if not contains:
        with open(configFile, 'a') as f:
            f.write(parameter+','+value+'\n')
            return True

    text = ''
    text2=''
    with open(configFile, 'r') as f:
        text = f.read()

    for line in text.split():
        words = line.split(',')

        if words[0] == parameter:
            text2 += parameter + ',' + value + '\n'
        else:
            text2 += line+'\n'

    with open(configFile, 'w') as f:
        f.write(text2)

    return True

#-----------------------
# Q3: Key Generation
#-----------------------
#-----------------------------------------------------------
# Parameters:   p (int)
#               q (int)
#               m (int): number of bits
# Return:       bitStream (str)
# Description:  Uses Blum Blum Shub Random Generation Algorithm to generates
#               a random stream of bits of size m
#               The seed is the nth prime number, where n = p*q
#               If the nth prime number is not relatively prime with n,
#               the next prime number is selected until a valid one is found
#               The prime numbers are read from the file primeFile (starting n=1)
# Error:        If number of bits is not a positive integer -->
#                   print('Error(blum): Invalid value of m',end =''), return ''
#               If p or q is not an integer that is congruent to 3 mod 4:
#                   print('Error(blum): Invalid values of p,q',end =''), return ''
#-----------------------------------------------------------
def blum(p,q,m):
    if not isinstance(m, int) or m <= 0:
        print('Error(blum): Invalid value of m',end ='')
        return ''

    if not isinstance(p, int) or not isinstance(q, int) or not mod.is_congruent(p, 3, 4) or not mod.is_congruent(q, 3, 4):
        print('Error(blum): Invalid values of p,q',end ='')
        return ''

    n = p*q
    i = 0
    x = ''
    with open(primeFile, 'r') as f:
        while i < n:
            x = f.readline()
            i += 1
        
        
        while not mod.is_relatively_prime(int(x), n):
            x = f.readline()

    xi = (int(x)**2) % n
    b = ''
    for i in range(0, m):
        xi = ((xi**2) % n)
        b = b + str(xi % 2)
        
    return b

#-----------------------------------------------------------
# Parameters:   None
# Return:       key (str)
# Description:  Generates an SDES key based on preconfigured values
#               The key size is fetched from the SDES configuration
#               If no key size is available, an error message is printed
#               Also, the values of p and q are fetched as per SDES configuration
#               If no values are found, the default values p = 383 and q = 503 are used
#               These values should be updated in the configuration file
#               The function calls the blum function to generate the key
# Error:        if key size is not defined -->
#                           print('Error(generate_key_SDES):Unknown Key Size',end=''), return ''
#-----------------------------------------------------------
def generate_key_SDES():
    size = get_SDES_value("key_size")
    if size == '':
        print('Error(generate_key_SDES):Unknown Key Size',end='')
        return ''

    p = get_SDES_value("p")
    q = get_SDES_value("q")

    if p == '':
        p = 383
    else:
        p = int(p)

    if q == '':
        q = 503
    else:
        q = int(q)

    key = blum(p,q,int(size))
    
    return key

#-----------------------------------------------------------
# Parameters:   key (str)
#               i (int)
# Return:       key (str)
# Description:  Generates a subkey for the ith round in SDES
#               The sub-key is one character shorter than original key size
#               Sub-key is generated by circular shift of key with value 1,
#               where i=1 means no shift
#               The least significant bit is dropped after the shift
# Errors:       if key is not a valid binary number or its length does not match key_size: -->
#                   print('Error(get_subKey): Invalid key',end='')
#               if i is not a positive integer:
#                   print('Error(get_subKey): invalid i',end=''), return ''
#-----------------------------------------------------------
def get_subKey(key,i):
    if not isinstance(i, int) or i < 1:
        print('Error(get_subKey): invalid i',end='')
        return ''

    p = set(key) 
    s = {'0', '1'} 
    if not (s == p or p == {'0'} or p == {'1'}) or len(key) != int(get_SDES_value("key_size")):
        print('Error(get_subKey): Invalid key',end='')
        return ''

    subKey = key

    for j in range(i-1):
        subKey =  subKey[1:] + subKey[0]

    subKey = subKey[:-1]

    return subKey

#-----------------------
# Q4: Fiestel Network
#-----------------------
#-----------------------------------------------------------
# Parameters:   R (str): binary number of size (block_size/2)
# Return:       output (str): expanded binary
# Description:  Expand the input binary number by adding two digits
#               The input binary number should be an even number >= 6
#               Expansion works as the following:
#               If the index of the two middle elements is i and i+1
#               From indices 0 up to i-1: same order
#               middle becomes: R(i+1)R(i)R(i+1)R(i)
#               From incides R(i+2) to the end: same order
# Error:        if R not a valid binary number or if it has an odd length
#               or is of length smaller than 6
#                   print('Error(expand): invalid input',end=''), return ''
#-----------------------------------------------------------
def expand(R):
    p = set(R) 
    s = {'0', '1'} 
    if not (s == p or p == {'0'} or p == {'1'}) or len(R)%2 == 1 or len(R) < 6:
        print('Error(expand): invalid input',end='')
        return ''

    i = int(len(R) / 2) - 1
    output = R[:i] + R[i+1] + R[i] + R[i+1] + R[i] + R[i+2:]

    return output

#-----------------------------------------------------------
# Parameters:   R (str): binary number of size (block_size//4)
# Return:       output (str): binary number
# Description:  Validates that R is of size block_size//4 + 1
#               Retrieves relevant structure of sbox1 from sbox1File
#               Most significant bit of R is row number, other bits are column number
# Error:        if undefined block_size:
#                   print('Error(sbox1): undefined block size',end=''), return ''
#               if invalid R:
#                   print('Error(sbox1): invalid input',end=''),return ''
#               if no sbox1 structure exist:
#                   print('Error(sbox1): undefined sbox1',end=''),return ''
#-----------------------------------------------------------       
def sbox1(R):

    if (get_SDES_value("block_size") == ''):
        print('Error(sbox1): undefined block size',end='')
        return ''

    if not isinstance(R, str):
        print('Error(sbox1): invalid input',end='')
        return ''

    p = set(R) 
    s = {'0', '1'} 
    if not (s == p or p == {'0'} or p == {'1'}) or len(R) != ((int(get_SDES_value("block_size"))//4) + 1):
        print('Error(sbox1): invalid input',end='')
        return ''

    text = ''
    with open(sbox1File, 'r') as f:
        text = f.read().split()

    if len(text) < len(R):
        print('Error(sbox1): undefined sbox1',end='')
        return ''


    for i in range(len(text)):
        lineArray = text[i].split(':')
        if int(lineArray[0]) == len(R):
            sboxText = lineArray[1].split(',')

    sboxArray = []
    sboxArray.append(sboxText[:int(len(sboxText)/2)])
    sboxArray.append(sboxText[int(len(sboxText)/2):])

    row = int(R[0])
    column = int(R[1:], 2)
    # if len(sboxArray[row])-1 < column:
    #     print('Error(sbox1): invalid input',end='')
    #     return ''

    output = sboxArray[row][column]
    return output

#-----------------------------------------------------------
# Parameters:   R (str): binary number of size (block_size//4)
# Return:       output (str): binary
# Description:  Validates that R is of size block_size//4 + 1
#               Retrieves relevant structure of sbox2 from sbox2File
#               Most significant bit of R is row number, other bits are column number
# Error:        if undefined block_size:
#                   print('Error(sbox2): undefined block size',end=''), return ''
#               if invalid R:
#                   print('Error(sbox2): invalid input',end=''),return ''
#               if no sbox1 structure exist:
#                   print('Error(sbox2): undefined sbox1',end=''),return ''
#-----------------------------------------------------------
def sbox2(R):
    if (get_SDES_value("block_size") == ''):
        print('Error(sbox2): undefined block size',end='')
        return ''

    if not isinstance(R, str):
        print('Error(sbox2): invalid input',end='')
        return ''

    p = set(R) 
    s = {'0', '1'} 
    if not (s == p or p == {'0'} or p == {'1'}) or len(R) != ((int(get_SDES_value("block_size"))//4) + 1):
        print('Error(sbox2): invalid input',end='')
        return ''

    text = ''
    with open(sbox2File, 'r') as f:
        text = f.read().split()

    if len(text) < len(R):
        print('Error(sbox2): undefined sbox2',end='')
        return ''


    for i in range(len(text)):
        lineArray = text[i].split(':')
        if int(lineArray[0]) == len(R):
            sboxText = lineArray[1].split(',')

    sboxArray = []
    sboxArray.append(sboxText[:int(len(sboxText)/2)])
    sboxArray.append(sboxText[int(len(sboxText)/2):])

    row = int(R[0])
    column = int(R[1:], 2)
    # if len(sboxArray[row])-1 < column:
    #     print('Error(sbox1): invalid input',end='')
    #     return ''

    output = sboxArray[row][column]
    return output

#-----------------------------------------------------------
# Parameters:   Ri (str): block of binary numbers
#               ki (str): binary number representing subkey
# Return:       Ri2 (str): block of binary numbers
# Description:  Performs the following five tasks:
#               1- Pass the Ri block to the expander function
#               2- Xor the output of [1] with ki
#               3- Divide the output of [2] into two equal sub-blocks
#               4- Pass the most significant bits of [3] to Sbox1
#                  and least significant bits to sbox2
#               5- Conactenate the output of [4] as [sbox1][sbox2]
# Error:        if ki is an invalid binary number:
#                   print('Error(F): invalid key',end=''), return ''
#               if invalid Ri:
#                   print('Error(F): invalid input',end=''),return ''
#-----------------------------------------------------------   
def F(Ri,ki):
    if not isinstance(ki, str):
        print('Error(F): invalid key',end='')
        return ''

    p = set(ki) 
    s = {'0', '1'}  
    if not (s == p or p == {'0'} or p == {'1'}) or 8 != len(ki):
        print('Error(F): invalid key',end='')
        return ''

    if not isinstance(Ri, str):
        print('Error(F): invalid input',end='')
        return ''

    p = set(Ri) 
    s = {'0', '1'}  
    if not (s == p or p == {'0'} or p == {'1'}) or 6 != len(Ri):
        print('Error(F): invalid input',end='')
        return ''


    #bin(6)[2:].zfill(8)
    Ri2 = expand(Ri)
    Ri2 = bin(int(Ri2, 2) ^ int(ki, 2))[2:].zfill(len(Ri2))
    oneVals = Ri2[:int(len(Ri2)/2)]
    twoVals = Ri2[int(len(Ri2)/2):]
    oneVals = sbox1(oneVals)
    twoVals = sbox2(twoVals)
    Ri2 = oneVals + twoVals
    return Ri2

#-----------------------------------------------------------
# Parameters:   bi (str): block of binary numbers
#               ki (str): binary number representing subkey
# Return:       bi2 (str): block of binary numbers
# Description:  Applies Fiestel Cipher on a block of binary numbers
#               L(current) = R(previous)
#               R(current) = L(previous)xor F(R(previous), subkey)
# Error:        if ki is an invalid binary number or of invalid size
#                   print('Error(feistel): Invalid key',end=''), return ''
#               if invalid Ri:
#                   print('Error(feistel): Invalid block',end=''),return ''
#----------------------------------------------------------- 
def feistel(bi,ki):
    if not isinstance(ki, str):
        print('Error(feistel): invalid key',end='')
        return ''

    p = set(ki) 
    s = {'0', '1'}  
    if not (s == p or p == {'0'} or p == {'1'}) or 8 != len(ki):
        print('Error(feistel): invalid key',end='')
        return ''

    if not isinstance(bi, str):
        print('Error(feistel): invalid input',end='')
        return ''

    p = set(bi) 
    s = {'0', '1'}  
    if not (s == p or p == {'0'} or p == {'1'}) or 12 != len(bi):
        print('Error(feistel): invalid input',end='')
        return ''

    L = bi[:int(len(bi)/2)]
    R = bi[int(len(bi)/2):]
    R = bin(int(L, 2) ^ int(F(R, ki), 2))[2:].zfill(len(R))

    bi2 = bi[int(len(bi)/2):] + R

    return bi2

#----------------------------------
# Q5: SDES Encryption/Decryption
#----------------------------------
#-----------------------------------------------------------
# Parameters:   plaintext (str)
#               key (str)
# Return:       ciphertext (str)
# Description:  Encryption using Simple DES
#----------------------------------------------------------- 
def e_SDES_ECB(plaintext,key):
    #'encoding_type','block_size','key_size','rounds','p','q'
    if plaintext == '' or get_SDES_value('encoding_type') == '' or get_SDES_value('block_size') == '' or get_SDES_value('key_size') == '' or get_SDES_value('rounds') == '':
        print("Error(e_SDES_ECB): Invalid input", end = '')
        return ''

    if key == '':
        if get_SDES_value('p') == '' or get_SDES_value('q') == '' or get_SDES_value('key_size') == '':
            print("Error(e_SDES_ECB): Invalid configuration", end = '')
            return ''
        else:
            key = generate_key_SDES()
    else:
        if len(key) != int(get_SDES_value('key_size')):
            print("Error(e_SDES_ECB): Invalid key", end = '')
            return ''

    encoding = utilities.get_B6Code()
    undefined = utilities.get_undefined(plaintext, encoding)
    plaintext = utilities.remove_undefined(plaintext, encoding)
    ciphertext = ''

    if len(plaintext) % 2 == 1:
        plaintext = plaintext + 'Q'

    rounds = int(get_SDES_value('rounds'))

    for i in range(0, int(len(plaintext)), 2):
        chars = encode_B6(plaintext[i]) + encode_B6(plaintext[i+1])
        for j in range(rounds):
            chars = feistel(chars, get_subKey(key, j+1))
        L = chars[:int(len(chars)/2)]
        R = chars[int(len(chars)/2):]
        ciphertext = ciphertext + decode_B6(R) + decode_B6(L)

    
    ciphertext = utilities.insert_undefinedList(ciphertext, undefined)
    
    return ciphertext

#-----------------------------------------------------------
# Parameters:   ciphertext (str)
#               key (str)
# Return:       plaintext (str)
# Description:  Decryption using Simple DES
#----------------------------------------------------------- 
def d_SDES_ECB(ciphertext,key):

    if ciphertext == '' or get_SDES_value('encoding_type') == '' or get_SDES_value('block_size') == '' or get_SDES_value('key_size') == '' or get_SDES_value('rounds') == '':
        print("Error(d_SDES_ECB): Invalid input", end = '')
        return ''

    if key == '':
        if get_SDES_value('p') == '' or get_SDES_value('q') == '' or get_SDES_value('key_size') == '':
            print("Error(d_SDES_ECB): Invalid configuration", end = '')
            return ''
        else:
            key = generate_key_SDES()
    else:
        if len(key) != int(get_SDES_value('key_size')):
            print("Error(d_SDES_ECB): Invalid key", end = '')
            return ''

    encoding = utilities.get_B6Code()
    undefined = utilities.get_undefined(ciphertext, encoding)
    ciphertext = utilities.remove_undefined(ciphertext, encoding)
    plaintext = ''

    rounds = int(get_SDES_value('rounds'))
    for i in range(0, int(len(ciphertext)), 2):
        chars = encode_B6(ciphertext[i]) + encode_B6(ciphertext[i+1])
        for j in range(rounds):
            chars = feistel(chars, get_subKey(key, rounds-j))
        L = chars[:int(len(chars)/2)]
        R = chars[int(len(chars)/2):]
        plaintext = plaintext + decode_B6(R) + decode_B6(L)
    
    if plaintext[-1] == 'Q':
        plaintext = plaintext[:-1]

    plaintext = utilities.insert_undefinedList(plaintext, undefined)

    return plaintext

def get_IV():
    bSize = get_SDES_value('block_size')
    result = blum(643,131,int(bSize))
    return result

def e_SDES_CBC(plaintext,key):
    return ''

def d_SDES_CBC(plaintext,key):
    return ''

def e_SDES_OFB(plaintext,key):
    return ''

def d_SDES_OFB(plaintext,key):
    return ''