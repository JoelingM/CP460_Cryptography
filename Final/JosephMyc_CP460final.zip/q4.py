#--------------------------
# CP460 (Fall 2019)
# Final Exam
# your name <----------------------
# your student ID <----------------
#--------------------------

import math
import string
import mod
import SDES
import utilities
import matrix

# add functions related to q4 here



def d_atbash(ciphertext):
    alpha = utilities.get_lower()
    ralpha = alpha[::-1]
    plaintext = ''
    for char in ciphertext:
        if char.isalpha():
            if char.isupper():
                i = ralpha.index(char.lower())
                plaintext += alpha[i].upper()
            else:
                i = ralpha.index(char)
                plaintext += alpha[i]
        else:
            plaintext += char

    return plaintext

#-----------------------------------------------------------
# Parameters:   text (str) 
# Return:       list: wordCount 
# Description:  Count frequency of letters in a given text
#               Returns a list, first element is count of 'a'
#               Counts both 'a' and 'A' as one character
#-----------------------------------------------------------
def get_charCount(text):
    return [text.count(chr(97+i))+text.count(chr(65+i)) for i in range(26)]


#-----------------------------------------------------------
# Parameters:   None 
# Return:       list 
# Description:  Return a list with English language letter frequencies
#               first element is frequency of 'a'
#-----------------------------------------------------------
def get_freqTable():
    freqTable = [0.08167,0.01492,0.02782, 0.04253, 0.12702,0.02228, 0.02015,
                 0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
                 0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
                 0.00978, 0.0236, 0.0015, 0.01974, 0.00074]
    return freqTable

#-----------------------------------------------------------
# Parameters:   text (string)
# Return:       double
# Description:  Calculates the Chi-squared statistics
#               chiSquared = for i=0(a) to i=25(z):
#                               sum( Ci - Ei)^2 / Ei
#               Ci is count of character i in text
#               Ei is expected count of character i in English text
#               Note: Chi-Squared statistics uses counts not frequencies
#-----------------------------------------------------------
def get_chiSquared(text):
    freqTable = get_freqTable()
    charCount = get_charCount(text)

    result = 0
    for i in range(26):
        Ci = charCount[i]
        Ei = freqTable[i]*len(text)
        result += ((Ci-Ei)**2)/Ei
    return result

#-------------------------------------------------------------------------------------
# Parameters:   plaintext(string)
#               key: (shifts,direction) (int,str)
# Return:       ciphertext (string)
# Description:  Encryption using Shfit Cipher (Monoalphabetic Substitituion)
#               The alphabet is shfited as many as "shifts" using given direction
#               Non alpha characters --> no substitution
#               Valid direction = 'l' or 'r'
#               Algorithm preserves case of the characters
#---------------------------------------------------------------------------------------
def e_shift(plaintext, key):
    alphabet = utilities.get_lower()

    shifts, direction = key
    if shifts < 0:
        shifts*=-1
        direction = 'l' if key[1] == 'r' else 'r'
    shifts = key[0]%26
    shifts = shifts if key[1] == 'l' else 26-shifts
    
    ciphertext = '' 
    for char in plaintext:                          
        if char.lower() in alphabet:
            plainIndx = alphabet.index(char.lower())    
            cipherIndx = (plainIndx + shifts)%26        
            cipherChar = alphabet[cipherIndx]
            ciphertext+= cipherChar.upper() if char.isupper() else cipherChar 
        else:
            ciphertext+= char
    return ciphertext

#-------------------------------------------------------------------------------------
# Parameters:   ciphertext(string)
#               key: (shifts,direction) (int,str)
# Return:       ciphertext (string)
# Description:  Decryption using Shfit Cipher (Monoalphabetic Substitituion)
#               The alphabet is shfited as many as "shifts" using given direction
#               Non alpha characters --> no substitution
#               Valid direction = 'l' or 'r'
#               Algorithm preserves case of the characters
#               Trick: Encrypt using same #shifts but the other direction
#---------------------------------------------------------------------------------------
def d_shift(ciphertext, key):
    direction = 'l' if key[1]== 'r' else 'r'
    return e_shift(ciphertext,(key[0],direction))

#-------------------------------------------------------------------------------------
# Parameters:   ciphertext(string)
# Return:       key,plaintext
# Description:  Cryptanalysis of shift cipher
#               Uses Chi-Square
#               Returns key and plaintext if successful
#               If cryptanalysis fails: returns '',''
#---------------------------------------------------------------------------------------
def cryptanalysis_shift(ciphertext):
    chiList = [round(get_chiSquared(d_shift(ciphertext,(i,'l'))),4) for i in range(26)]
    key = chiList.index(min(chiList))
    key = (key,'l')
    plaintext = d_shift(ciphertext,key)
    return key,plaintext

#---------------------------------
#  Columnar Transposition    #
#---------------------------------
#-----------------------------------------------------------
# Parameters:   key (string)           
# Return:       keyOrder (list)
# Description:  checks if given key is a valid columnar transposition key 
#               Returns key order, e.g. [face] --> [1,2,3,0]
#               Removes repititions and non-alpha characters from key
#               If empty string or not a string -->
#                   print an error msg and return [0] (which is a)
#               Upper 'A' and lower 'a' are the same order
#-----------------------------------------------------------
def get_keyOrder_columnarTrans(key):
    #Check if it is a valid key
    if (not isinstance(key, str)):
        print("Error: Invalid Columnar Transposition Key ", end = '')
        return [0]

    newStr = ""
    for char in key:
        if char.isalpha() and char not in newStr:
            newStr += char.lower()

    if (newStr == ""):
        print("Error: Invalid Columnar Transposition Key ", end = '')
        return [0]

    newStr2 = newStr
    keyOrder = []

    newStr2 = sorted(newStr2)

    for char in newStr2:
        keyOrder.append(newStr.index(char))

    return keyOrder


def text_to_blocks(text,size):
    return [text[i*size:(i+1)*size] for i in range(math.ceil(len(text)/size))]

#-----------------------------------------------------------
# Parameters:   plaintext (str)
#               kye (str)
# Return:       ciphertext (list)
# Description:  Encryption using Columnar Transposition Cipher
#-----------------------------------------------------------
def e_columnarTrans(plaintext,key):
    keyArray = get_keyOrder_columnarTrans(key)    

    size = len(keyArray)

    for i in range(size - (len(plaintext) % len(keyArray))):
        plaintext += 'q'

    plainArray = text_to_blocks(plaintext,size)
    
    ciphertext = ""
    for i in range(size):
        for j in range(len(plainArray)):
            ciphertext += plainArray[j][keyArray[i]]

    return ciphertext

#-----------------------------------------------------------
# Parameters:   ciphertext (str)
#               kye (str)
# Return:       plaintext (list)
# Description:  Decryption using Columnar Transposition Cipher
#-----------------------------------------------------------
def d_columnarTrans(ciphertext,key):
    keyArray = get_keyOrder_columnarTrans(key)    

    size = int(len(ciphertext)/len(keyArray))

    cipherArray = text_to_blocks(ciphertext,size)

    plaintext = ""
    for i in range(size):
        for j in range(len(cipherArray)):
            plaintext += cipherArray[keyArray.index(j)][i]
    
    while plaintext[-1] == 'q':
        plaintext = plaintext[:-1]
        
    return plaintext


#----------------------------------------------------
# Parameters:   None
# Return:       polybius_square (string)
# Description:  Returns the following polybius square
#               as a sequential string:
#               [1] [2]  [3] [4] [5] [6] [7] [8]
#           [1]      !    "   #   $   %   &   '
#           [2]  (   )    *   +   '   -   .   /
#           [3]  0   1    2   3   4   5   6   7
#           [4]  8   9    :   ;   <   =   >   ?
#           [5]  @   A    B   C   D   E   F   G
#           [6]  H   I    J   K   L   M   N   O
#           [7]  P   Q    R   S   T   U   V   W
#           [8]  X   Y    Z   [   \   ]   ^   _
#---------------------------------------------------
def get_polybius_square():
    polybius_square = ''
    for i in range(32, 96):
        polybius_square += chr(i)
    # your code here
    return polybius_square
    
#-------------------------------------------------------
# Parameters:   ciphertext(string)
#               key (none)
# Return:       plaintext (string)
# Description:  Decryption using Polybius Square Cipher
#               Detects invalid ciphertext --> print error msg and return ''
#               Case 1: #of chars (other than \n) is not even
#               Case 2: the ciphertext contains non-numerical chars (except \n')
#-------------------------------------------------------
def d_polybius(ciphertext):
    plaintext = ''
    poly = get_polybius_square()
    #Remove newline characters
    stripString = ciphertext.replace('\n', '')
    #Check that there is an even number of number
    if ( (len(stripString)) % 2 != 0):
        print("Invalid ciphertext! Decryption Failed!")
        return ''

    for char in stripString:
        if (not char.isdigit()):
            print("Invalid ciphertext! Decryption Failed!")
            return ''

    i = 0
    while (i < len(ciphertext)):
        
        #Handle newline character (fails if \n#\n).
        if (ciphertext[i] == '\n'):
            plaintext += ciphertext[i]
            i += 1
        #Decode each character
        else:
            plaintext += poly[(int(ciphertext[i])-1)*8 + (int(ciphertext[i+1])-1)]
            i+= 2

    return plaintext

#---------------------------------
#       Q5: Hill Cipher          #
#---------------------------------

#-----------------------------------------------------------
# Parameters:   plaintext (str)
#               key (str)
# Return:       ciphertext (str)
# Description:  Encryption using Hill Cipher, 2x2 (mod 26)
#               key is a string consisting of 4 characters
#                   if key is too short, make it a running key
#                   if key is too long, use first 4 characters
#               Encrypts only alphabet
#               Case of characters can be ignored --> cipher is upper case
#               If necessary pad with 'Q'
# Errors:       if key is not inveritble or if plaintext is empty
#                   print error msg and return empty string
#-----------------------------------------------------------
def e_hill(plaintext,key):
    if len(key) > 4:
        key = key[:4]
    elif len(key) < 4 and len(key) > 0:
        i = 0
        while len(key) < 4:
            key = key + key[i]
            i += 1

    elif len(key) < 0:
        print("Error(e_hill): key is not invertible")
        return ""

    if len(plaintext) == 0:
        print("Error(e_hill): invalid plaintext")
        return ""

    alphaString = utilities.get_lower()
    key = key.lower()
    keyArray = matrix.new_matrix(2, 2, 0)
    keyArray[0][0] = alphaString.index(key[0])
    keyArray[0][1] = alphaString.index(key[1])
    keyArray[1][0] = alphaString.index(key[2])
    keyArray[1][1] = alphaString.index(key[3])

    det = keyArray[0][0]*keyArray[1][1] - keyArray[0][1]*keyArray[1][0]
    if mod.mul_inv(det, 26) == "NA":
        print('Error(e_hill): key is not invertible') 
        return ""

    #Format plaintext for encryption
    plaintext = plaintext.lower()
    nonAlpha = utilities.get_nonalpha(plaintext)
    plaintext = utilities.remove_nonalpha(plaintext)
    if len(plaintext) % 2 == 1:
        plaintext += 'q'

    ciphertext = ""
    tempArray = matrix.new_matrix(2, 1, 0)
    for i in range(0, len(plaintext), 2):
        tempArray[0][0] = alphaString.index(plaintext[i])
        tempArray[1][0] = alphaString.index(plaintext[i+1])
    
        newArray = matrix.mul(keyArray, tempArray)

        ciphertext += alphaString[newArray[0][0] % 26]
        ciphertext += alphaString[newArray[1][0] % 26]

    ciphertext = utilities.insert_nonalpha(ciphertext, nonAlpha)

    return ciphertext.upper()

#-----------------------------------------------------------
# Parameters:   ciphertext (str)
#               key (str)
# Return:       plaintext (str)
# Description:  Decryption using Hill Cipher, 2x2 (mod 26)
#               key is a string consisting of 4 characters
#                   if key is too short, make it a running key
#                   if key is too long, use first 4 characters
#               Decrypts only alphabet
#               Case of characters can be ignored --> plain is lower case
#               Remove padding of q's
# Errors:       if key is not inveritble or if ciphertext is empty
#                   print error msg and return empty string
#-----------------------------------------------------------
def d_hill(ciphertext,key):
    if len(key) > 4:
        key = key[:4]
    elif len(key) < 4 and len(key) > 0:
        i = 0
        while len(key) < 4:
            key = key + key[i]
            i += 1

    elif len(key) < 0:
        print("Error(d_hill): key is not invertible")
        return ""

    if len(ciphertext) == 0:
        print("Error(d_hill): invalid ciphertext")
        return ""

    alphaString = utilities.get_lower()
    key = key.lower()
    keyArray = matrix.new_matrix(2, 2, 0)
    keyArray[0][0] = alphaString.index(key[0])
    keyArray[0][1] = alphaString.index(key[1])
    keyArray[1][0] = alphaString.index(key[2])
    keyArray[1][1] = alphaString.index(key[3])

    det = keyArray[0][0]*keyArray[1][1] - keyArray[0][1]*keyArray[1][0]
    if not mod.has_mul_inv(det, 26):
        print('Error(d_hill): key is not invertible') 
        return ""
    
    keyArray = matrix.inverse(keyArray, 26)

    #Format plaintext for encryption
    ciphertext = ciphertext.lower()
    nonAlpha = utilities.get_nonalpha(ciphertext)
    ciphertext = utilities.remove_nonalpha(ciphertext)

    plaintext = ""
    tempArray = matrix.new_matrix(2, 1, 0)
    for i in range(0, len(ciphertext), 2):
        tempArray[0][0] = alphaString.index(ciphertext[i])
        tempArray[1][0] = alphaString.index(ciphertext[i+1])
    
        newArray = matrix.mul(keyArray, tempArray)

        plaintext += alphaString[newArray[0][0] % 26]
        plaintext += alphaString[newArray[1][0] % 26]

    plaintext = utilities.insert_nonalpha(plaintext, nonAlpha)
    
    if plaintext[-1] == 'q':
        plaintext = plaintext[:-1]

    return plaintext

def has_det_inv(key):
    alphaString = utilities.get_lower()
    key = key.lower()
    keyArray = matrix.new_matrix(2, 2, 0)
    keyArray[0][0] = alphaString.index(key[0])
    keyArray[0][1] = alphaString.index(key[1])
    keyArray[1][0] = alphaString.index(key[2])
    keyArray[1][1] = alphaString.index(key[3])

    det = keyArray[0][0]*keyArray[1][1] - keyArray[0][1]*keyArray[1][0]
    
    if mod.mul_inv(det, 26) == "NA":
        return False
    return True